# Windows PowerShell orqali Kredit Botni ishga tushirish qo'llanmasi

Ushbu qo'llanma @Kredit12bot Telegram botini o'zingizning Windows kompyuteringizda PowerShell orqali qanday o'rnatish va ishga tushirishni bosqichma-bosqich tushuntiradi.

## 1-bosqich: Python o'rnatish
Agar kompyuteringizda Python o'rnatilmagan bo'lsa, uni [python.org](https://www.python.org/downloads/) saytidan yuklab oling va o'rnating. O'rnatish vaqtida **"Add Python to PATH"** katakchasini belgilashni unutmang.

## 2-bosqich: PowerShell'ni ochish va kutubxonalarni o'rnatish
PowerShell terminalini oching va quyidagi buyruqni nusxalab, Enter tugmasini bosing:

```powershell
pip install aiogram python-docx reportlab pandas openpyxl
```

## 3-bosqich: Bot kodini yaratish
Kompyuteringizda yangi papka oching (masalan, `C:\KreditBot`). Shu papka ichida `kredit_bot.py` nomli fayl yarating va unga men taqdim etgan kodni saqlang.

## 4-bosqich: Botni ishga tushirish
PowerShell'da bot joylashgan papkaga o'ting va botni ishga tushiring:

```powershell
cd C:\KreditBot
python kredit_bot.py
```

## Kerakli buyruqlar jadvali

| Vazifa | Buyruq |
| :--- | :--- |
| Python versiyasini tekshirish | `python --version` |
| Kutubxonalarni o'rnatish | `pip install aiogram python-docx reportlab pandas openpyxl` |
| Botni ishga tushirish | `python kredit_bot.py` |
| Botni to'xtatish | `Ctrl + C` |

> **Eslatma:** Bot 24/7 ishlashi uchun PowerShell oynasi doimo ochiq turishi va kompyuter internetga ulangan bo'lishi kerak.
