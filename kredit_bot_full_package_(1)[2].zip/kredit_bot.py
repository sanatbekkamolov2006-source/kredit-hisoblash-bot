import os
import asyncio
import math
import sys
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, FSInputFile
from docx import Document
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

# Windows'da UTF-8 kodlashni majburiy qilish (o'zbekcha harflar uchun)
if sys.platform == "win32":
    import codecs
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

# Bot token
TOKEN = "8627500627:AAF1PBIC8PFFX5kph_OekzsslDtnufjPAi4"

bot = Bot(token=TOKEN)
dp = Dispatcher()

class CreditStates(StatesGroup):
    waiting_for_amount = State()
    waiting_for_rate = State()
    waiting_for_term = State()
    waiting_for_type = State()
    waiting_for_format = State()

def calculate_annuity(amount, rate, term):
    monthly_rate = rate / 100 / 12
    monthly_payment = amount * (monthly_rate * (1 + monthly_rate) ** term) / ((1 + monthly_rate) ** term - 1)
    
    schedule = []
    remaining_balance = amount
    total_interest = 0
    
    for i in range(1, term + 1):
        interest_payment = remaining_balance * monthly_rate
        principal_payment = monthly_payment - interest_payment
        remaining_balance -= principal_payment
        total_interest += interest_payment
        
        schedule.append({
            "Oy": i,
            "To_lov": round(monthly_payment, 2),
            "Asosiy qarz": round(principal_payment, 2),
            "Foiz": round(interest_payment, 2),
            "Qoldiq": round(max(0, remaining_balance), 2)
        })
    
    return schedule, round(monthly_payment, 2), round(total_interest, 2)

def calculate_differential(amount, rate, term):
    monthly_rate = rate / 100 / 12
    principal_payment = amount / term
    
    schedule = []
    remaining_balance = amount
    total_interest = 0
    
    for i in range(1, term + 1):
        interest_payment = remaining_balance * monthly_rate
        monthly_payment = principal_payment + interest_payment
        remaining_balance -= principal_payment
        total_interest += interest_payment
        
        schedule.append({
            "Oy": i,
            "To_lov": round(monthly_payment, 2),
            "Asosiy qarz": round(principal_payment, 2),
            "Foiz": round(interest_payment, 2),
            "Qoldiq": round(max(0, remaining_balance), 2)
        })
        
    return schedule, total_interest

@dp.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    await message.answer("Assalomu alaykum! Kredit hisoblash botiga xush kelibsiz.\nKredit miqdorini kiriting (masalan: 10000000):")
    await state.set_state(CreditStates.waiting_for_amount)

@dp.message(CreditStates.waiting_for_amount)
async def process_amount(message: types.Message, state: FSMContext):
    try:
        amount = float(message.text)
        await state.update_data(amount=amount)
        await message.answer("Yillik foiz stavkasini kiriting (masalan: 24):")
        await state.set_state(CreditStates.waiting_for_rate)
    except ValueError:
        await message.answer("Iltimos, faqat raqam kiriting:")

@dp.message(CreditStates.waiting_for_rate)
async def process_rate(message: types.Message, state: FSMContext):
    try:
        rate = float(message.text)
        await state.update_data(rate=rate)
        await message.answer("Kredit muddatini oylarda kiriting (masalan: 12):")
        await state.set_state(CreditStates.waiting_for_term)
    except ValueError:
        await message.answer("Iltimos, faqat raqam kiriting:")

@dp.message(CreditStates.waiting_for_term)
async def process_term(message: types.Message, state: FSMContext):
    try:
        term = int(message.text)
        await state.update_data(term=term)
        
        kb = ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="Annuitet"), KeyboardButton(text="Differensial")]
        ], resize_keyboard=True)
        
        await message.answer("Kredit turini tanlang:", reply_markup=kb)
        await state.set_state(CreditStates.waiting_for_type)
    except ValueError:
        await message.answer("Iltimos, butun son kiriting:")

@dp.message(CreditStates.waiting_for_type)
async def process_type(message: types.Message, state: FSMContext):
    if message.text not in ["Annuitet", "Differensial"]:
        await message.answer("Iltimos, tugmalardan birini tanlang.")
        return
    
    await state.update_data(type=message.text)
    
    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="PDF"), KeyboardButton(text="Word")]
    ], resize_keyboard=True)
    
    await message.answer("Natijani qaysi formatda olishni xohlaysiz?", reply_markup=kb)
    await state.set_state(CreditStates.waiting_for_format)

@dp.message(CreditStates.waiting_for_format)
async def process_format(message: types.Message, state: FSMContext):
    if message.text not in ["PDF", "Word"]:
        await message.answer("Iltimos, tugmalardan birini tanlang.")
        return
    
    data = await state.get_data()
    amount = data['amount']
    rate = data['rate']
    term = data['term']
    credit_type = data['type']
    file_format = message.text
    
    if credit_type == "Annuitet":
        schedule, monthly, total_interest = calculate_annuity(amount, rate, term)
        summary_text = f"Kredit turi: Annuitet\nSumma: {amount:,.2f}\nFoiz: {rate}%\nMuddat: {term} oy\nHar oylik to'lov: {monthly:,.2f}\nJami foiz: {total_interest:,.2f}"
    else:
        schedule, total_interest = calculate_differential(amount, rate, term)
        summary_text = f"Kredit turi: Differensial\nSumma: {amount:,.2f}\nFoiz: {rate}%\nMuddat: {term} oy\nJami foiz: {total_interest:,.2f}"

    file_path = f"kredit_hisob_{message.from_user.id}"
    
    if file_format == "Word":
        file_path += ".docx"
        doc = Document()
        doc.add_heading('Kredit Hisob-kitobi', 0)
        doc.add_paragraph(summary_text)
        
        table = doc.add_table(rows=1, cols=5)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = 'Oy'
        hdr_cells[1].text = "To'lov"
        hdr_cells[2].text = 'Asosiy qarz'
        hdr_cells[3].text = 'Foiz'
        hdr_cells[4].text = 'Qoldiq'
        
        for item in schedule:
            row_cells = table.add_row().cells
            row_cells[0].text = str(item['Oy'])
            row_cells[1].text = f"{item['To_lov']:,.2f}"
            row_cells[2].text = f"{item['Asosiy qarz']:,.2f}"
            row_cells[3].text = f"{item['Foiz']:,.2f}"
            row_cells[4].text = f"{item['Qoldiq']:,.2f}"
        
        doc.save(file_path)
    else:
        file_path += ".pdf"
        doc = SimpleDocTemplate(file_path, pagesize=letter)
        styles = getSampleStyleSheet()
        elements = []
        
        elements.append(Paragraph("Kredit Hisob-kitobi", styles['Title']))
        elements.append(Paragraph(summary_text.replace('\n', '<br/>'), styles['Normal']))
        
        data_list = [['Oy', "To'lov", 'Asosiy qarz', 'Foiz', 'Qoldiq']]
        for item in schedule:
            data_list.append([
                str(item['Oy']),
                f"{item['To_lov']:,.2f}",
                f"{item['Asosiy qarz']:,.2f}",
                f"{item['Foiz']:,.2f}",
                f"{item['Qoldiq']:,.2f}"
            ])
        
        t = Table(data_list)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        elements.append(t)
        doc.build(elements)

    await message.answer(summary_text)
    await message.answer_document(FSInputFile(file_path), caption="Sizning hisob-kitobingiz")
    
    if os.path.exists(file_path):
        os.remove(file_path)
        
    await state.clear()

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
